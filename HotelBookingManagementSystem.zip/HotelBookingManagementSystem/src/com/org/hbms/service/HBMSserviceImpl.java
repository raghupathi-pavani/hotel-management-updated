package com.org.hbms.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.dao.HBMSDaoImpl;
import com.org.hbms.dao.IHBMSDao;
import com.org.hbms.exception.HBMSException;

public class HBMSserviceImpl implements IHBMSservice{

	@Override
	public int registerUser(HBMSUserBean b) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.registerUser(b);		
	}

	@Override
	public boolean validateUserLogin(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.validateUserLogin(username,password);
	}

	@Override
	public StringBuilder getHotelDetails() throws HBMSException{
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getHotelDetails();
	}

	@Override
	public HBMSUserBean getUserDetails(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getUserDetails(username,password);
	}

	@Override
	public StringBuilder displayRooms(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.displayRooms(hotel_id);
	}

	@Override
	public boolean isValidHotelId(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.isValidHotelId(hotel_id);
	}

	@Override
	public boolean validateAdminLogin(String username, String password) {
		if(username.equals("admin") && password.equals("admin"))
		{
			return true;
		}
		return false;
	}

	@Override
	public void addHotelDetails(HBMSHotelBean hotel) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.addHotelDetails(hotel);
	}

	@Override
	public void deleteHotel(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteHotel(hotelId);
	}

	@Override
	public void deleteHotelRooms(String hotelId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteHotelRooms(hotelId);
	}

	@Override
	public void addRoomDetails(HBMSRoomBean room) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.addRoomDetails(room);
	}

	@Override
	public boolean isValidRoomId(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.isValidRoomId(roomId);
	}

	@Override
	public void deleteRoom(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		d1.deleteRoom(roomId);
		
	}

	@Override
	public float getRoomAmount(String roomId) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getRoomAmount(roomId);
	}

	@Override
	public String addBookingDetails(HBMSBookingBean booking) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.addBookingDetails(booking);
	}

	@Override
	public boolean isValidUsername(String rUserName) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("[A-Z|a-z]{19}");
		Matcher nameMatcher=namePattern.matcher(rUserName);
		return nameMatcher.matches();
	}
	@Override
	public boolean isValidPassword(String rPassword) {
		int length=rPassword.length();
		if(length>7 || length<0)
		{
			return false;
		}
		return true;
	}
	@Override
	public boolean isValidMobileNo(String rMobileNo) {
		// TODO Auto-generated method stub
		Pattern mobilePattern=Pattern.compile("[1-9][0-9]{9}");
		Matcher mobileMatcher=mobilePattern.matcher(rMobileNo);
		return mobileMatcher.matches();
	}

	@Override
	public boolean isValidPhoneNo(String rPhone) {
		// TODO Auto-generated method stub
		Pattern phonePattern=Pattern.compile("[1-9][0-9]{9}");
		Matcher phoneMatcher=phonePattern.matcher(rPhone);
		return phoneMatcher.matches();
	}

	@Override
	public boolean isValidAddress(String rAddress) {
		// TODO Auto-generated method stub
		int length=rAddress.length();
		if(length>25 || length<0)
		{
			return false;
		}
		return true;
		
	}

	@Override
	public boolean isValidEmailId(String rEmail) {
		Pattern namePattern=Pattern.compile(".*@.*");
		Matcher nameMatcher=namePattern.matcher(rEmail);
		return nameMatcher.matches();
	}

	@Override
	public boolean isValidCity(String city) {
		Pattern citynamePattern=Pattern.compile("[A-Z][a-z]{9}");
		Matcher citynameMatcher=citynamePattern.matcher(city);
		return citynameMatcher.matches();
		
	}

	@Override
	public boolean isValidHotelName(String hotelName) {
		Pattern hotelnamePattern=Pattern.compile("[A-Z|a-z]{19}");
		Matcher hotelnameMatcher=hotelnamePattern.matcher(hotelName);
		return hotelnameMatcher.matches();
		
	}

	@Override
	public boolean isValidHotelAddress(String address) {
		int length=address.length();
		if(length>25 || length<0)
		{
			return false;
		}
		return true;
	}

	@Override
	public boolean isValidHotelDescription(String description) {
		int length=description.length();
		if(length>50 || length<0)
		{
			return false;
		}
		return true;
	}

	@Override
	public boolean isValidAvgRate(String avgRatePerNight) {
		
		Pattern avgRatePattern=Pattern.compile("[0-9]*");
		Matcher avgRateMatcher=avgRatePattern.matcher(avgRatePerNight);
		return avgRateMatcher.matches();
	}

	@Override
	public boolean isValidPhoneNo1(String phoneNo1) {
		Pattern phonePattern=Pattern.compile("[1-9][0-9]{9}");
		Matcher phoneMatcher=phonePattern.matcher(phoneNo1);
		return phoneMatcher.matches();
		
	}

	@Override
	public boolean isValidPhoneNo2(String phoneNo2) {
		Pattern phonePattern=Pattern.compile("[1-9][0-9]{9}");
		Matcher phoneMatcher=phonePattern.matcher(phoneNo2);
		return phoneMatcher.matches();
	}

	@Override
	public boolean isValidRating(String rating) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isValidEmail(String email) {
		Pattern emailPattern=Pattern.compile(".*@.*");
		Matcher emailMatcher=emailPattern.matcher(email);
		return emailMatcher.matches();
		
	}

	@Override
	public boolean isValidFaxNo(String fax) {
		Pattern faxPattern=Pattern.compile("+1[0-9]{14}");
		Matcher faxMatcher=faxPattern.matcher(fax);
		return faxMatcher.matches();
	}

	@Override
	public boolean isValidRoomno(String roomNo) 
	{
		Pattern roomnoPattern=Pattern.compile("[1-9][0-9]{3}");
		Matcher roomnoMatcher=roomnoPattern.matcher(roomNo);
		return roomnoMatcher.matches();
	}

	@Override
	public boolean isValidDate(String date1) {
		Pattern datePattern=Pattern.compile("[0-9]{1,2}(/|-)[0-9]{1,2}(/|-)[0-9]{4}");
		Matcher dateMatcher=datePattern.matcher(date1);
		return dateMatcher.matches();
		
	}

	@Override
	public boolean isValidDate2(String date2) {
		
		Pattern date1Pattern=Pattern.compile("[0-9]{1,2}(/|-)[0-9]{1,2}(/|-)[0-9]{4}");
		Matcher date1Matcher=date1Pattern.matcher(date2);
		return date1Matcher.matches();
	}


}
