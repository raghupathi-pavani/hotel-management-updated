package com.org.hbms.service;

import com.org.hbms.bean.HBMSBookingBean;
import com.org.hbms.bean.HBMSHotelBean;
import com.org.hbms.bean.HBMSRoomBean;
import com.org.hbms.bean.HBMSUserBean;
import com.org.hbms.exception.HBMSException;

public interface IHBMSservice {

	int registerUser(HBMSUserBean b) throws HBMSException;

	boolean validateUserLogin(String username, String password) throws HBMSException;

	StringBuilder getHotelDetails() throws HBMSException;

	HBMSUserBean getUserDetails(String username, String password) throws HBMSException;

	boolean isValidPassword(String rPassword);

	StringBuilder displayRooms(String hotel_id) throws HBMSException;

	boolean isValidHotelId(String hotel_id) throws HBMSException;

	boolean validateAdminLogin(String username, String password);

	void addHotelDetails(HBMSHotelBean hotel) throws HBMSException;

	void deleteHotel(String hotelId) throws HBMSException;

	void deleteHotelRooms(String hotelId) throws HBMSException;

	void addRoomDetails(HBMSRoomBean room) throws HBMSException;

	boolean isValidRoomId(String roomId) throws HBMSException;

	void deleteRoom(String roomId) throws HBMSException;

	float getRoomAmount(String roomId) throws HBMSException;

	String addBookingDetails(HBMSBookingBean booking) throws HBMSException;

	boolean isValidUsername(String rUserName);

	boolean isValidMobileNo(String rMobileNo);

	boolean isValidPhoneNo(String rPhone);

	boolean isValidAddress(String rAddress);

	boolean isValidEmailId(String rEmail);

	boolean isValidCity(String city);

	boolean isValidHotelName(String hotelName);

	boolean isValidHotelAddress(String address);

	boolean isValidHotelDescription(String description);

	boolean isValidAvgRate(String avgRatePerNight);

	boolean isValidPhoneNo1(String phoneNo1);

	boolean isValidPhoneNo2(String phoneNo2);

	boolean isValidRating(String rating);

	boolean isValidEmail(String email);

	boolean isValidFaxNo(String fax);

	boolean isValidRoomno(String roomNo);

	boolean isValidDate(String date1);

	boolean isValidDate2(String date2);

	

}
